from django.contrib import admin

from myapp.models import InvestorProfile, Startup 

# Register your models here.
admin.site.register(InvestorProfile)
admin.site.register(Startup)