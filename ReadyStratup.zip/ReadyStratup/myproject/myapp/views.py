# myapp/views.py
from django.http import HttpResponse
from django.shortcuts import render, redirect,HttpResponse
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from .forms import UserRegistrationForm
from django.contrib.auth.forms import AuthenticationForm
from .forms import UserRegistrationForm
from django.http import HttpResponse

from myapp.models import InvestorProfile, Startup

def index(request):
    return render(request,'index.html')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserRegistrationForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

def home(request):
    if request.user.is_authenticated:

        details=InvestorProfile.objects.all()
    
    if request.method=='GET':
        st=request.GET.get('search')
        if st!=None:
            details=InvestorProfile.objects.filter(name=st)
    context={
        'details':details
    }

    if request.user.is_authenticated:
        return render(request,'home.html',context)
    else:
        return HttpResponse("PLz login")
    



def desc(request):
    detaile=InvestorProfile.objects.all()
    context={
        'detaile':detaile
    }

    return render(request,'desc.html',context)

def startup(request):
    start=Startup.objects.all()

    if request.method=='GET':
        st=request.GET.get('sear')
        if st!=None:
            start=Startup.objects.filter(wonername=st)
    context={
        'start':start
    }

    if request.method == 'POST':
        image=request.POST['image']
        wonername = request.POST['wonername']
        companyname = request.POST['companyname']
        email = request.POST['email']
        linkdin = request.POST['linkdin']
        website = request.POST['website']
        description = request.POST['description']
        location = request.POST['location']
        workfield = request.POST['workfield']

        info = Startup(image=image,wonername=wonername,companyname=companyname,email=email,linkdin=linkdin,website=website,description=description,location=location,workfield=workfield)

        info.save()
        return redirect ('sucessfully')
        

    return render(request,'startup.html',context)

def profile(request):
    profilepage=Startup.objects.all()
    context={
        'profilepage':profilepage
    }

    return render(request,'profile.html',context)

def form(request):

    if request.method == 'POST':
        # Extract data from POST request
        name = request.POST.get('name')
        companyname = request.POST.get('companyname')
        email = request.POST.get('email')
        linkdin = request.POST.get('linkdin')
        website = request.POST.get('website')
        description = request.POST.get('description')
        location = request.POST.get('location')
        investindustries = request.POST.get('investindustries')

        # Handle image upload
        image = request.FILES.get('InvestorProfile')

        # Create and save BusinessProfile instance
        data = InvestorProfile(
            name=name,
            image=image,
            companyname=companyname,
            email=email,
            linkdin=linkdin,
            website=website,
            description=description,
            location=location,
            investindustries=investindustries
        )
        data.save()

        return HttpResponse('success')

    return render(request, 'form.html')


    
    
