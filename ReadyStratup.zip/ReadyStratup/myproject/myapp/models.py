from django.db import models

# Create your models here.
class InvestorProfile(models.Model):
    name=models.CharField(max_length=30)
    image=models.ImageField(upload_to='InvestorProfile')
    companyname=models.CharField(max_length=70)
    email=models.EmailField()
    linkdin=models.CharField(max_length=70)
    website=models.CharField(max_length=50)
    description=models.TextField()
    location=models.CharField(max_length=40)
    investindustries=models.CharField(max_length=200)

class Startup(models.Model):
    wonername=models.CharField(max_length=30)
    image=models.ImageField(upload_to='Startup')
    companyname=models.CharField(max_length=70)
    email=models.EmailField()
    linkdin=models.CharField(max_length=70)
    website=models.CharField(max_length=50)
    description=models.TextField()
    location=models.CharField(max_length=40)
    workfield=models.CharField(max_length=200)

